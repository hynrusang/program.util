package util;
import util.file.*;

final public class CUI {
	public static void start() {
		
	}
	private CUI() { }
}