package util;
import util.file.*;

final public class GUI {
	public static void start() {
		
	}
	private GUI() { }
}