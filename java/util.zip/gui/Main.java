package util.gui;
import util.*;
import util.file.*;

final public class Main {
	public static void start() {
		
	}
}